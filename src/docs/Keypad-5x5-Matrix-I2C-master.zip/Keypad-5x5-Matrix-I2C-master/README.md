# Keypad-5x5-Matrix-I2C
Keypad 5x5 Matrix I2C MCP23017 Development Booard.
These codes are designed/modified for a Keypad 5x5 Matrix 
that uses an I2C connection by using with MCP23017
These sample code are also compatible for new board (v1.1)
